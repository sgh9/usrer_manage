import React, { useState, useEffect } from 'react';
import { useParams } from "react-router-dom";


 function ManageUsersForm() {
    const [user, setUser] = useState({
        firstName: '',
        lastName: '',
        email: '',
    });

    const [message, setMessage] = useState("");
    const [loading, setLoading] = useState(false);
    const [showAlert, setShowAlert] = useState(false);
    const [updateUser, setUpdateUser] = useState(false);
    const { userId } = useParams();

    const reset = () => {
        setUser({
            firstName: '',
            lastName: '',
            email: '',
        });

        setLoading(false);
    }

    const addNewUser = async (e) => {
        e.preventDefault();
        setLoading(true);

        let baseURL = 'http://localhost:8082/users';

        const res = await fetch(baseURL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                // 'Access-Control-Allow-Origin:': ''
            },
            body: JSON.stringify(user)
        });

        const data = await res.json();
        if (res.ok) {
            setMessage(data.msg);
        } else {
            setMessage(data.msg);
        }
        showAlertMsg();
        reset();
    }

    const updateUserDetails = async (e) => {
        e.preventDefault();

        let baseURL = `http://localhost:8082/users/${userId}`;

        const res = await fetch(baseURL, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(user)
        });

        const data = await res.json();
        if (res.ok) {
            setMessage(data.msg);
        } else {
            setMessage(data.msg);
        }
        showAlertMsg();
    }

    const getUser = async (id) => {
        setLoading(true);
        let baseURL = `http://localhost:8082/users/${userId}`;

        const res = await fetch(baseURL);
        const data = await res.json();
        if (res.ok) {
            setUser(data);
            setLoading(false);
        } else {
            setMessage(data.msg);
            setLoading(false);
            showAlertMsg();
        }
    }


    const handleChange = (e) => {
        const { name, value } = e.target;
        let newUser = { ...user, [name]: value };
        setUser(newUser);
    }

    const showAlertMsg = () => {
        setShowAlert(true);
        setTimeout(() => setShowAlert(false), 2000);
    }

    useEffect(() => {

        if (userId !== 'new') {
            getUser();
            setUpdateUser(true);
        }
    }, [])

    return (
        <div className="container pt-4">
            <div className="row">
                <div className="col-5 mx-auto">
                    <div className={`alert alert-success ${showAlert ? 'd-block' : 'd-none'}`}>
                        <strong>Success! </strong>{message}
                    </div>
                    <form onSubmit={(e) => updateUser ? updateUserDetails(e) : addNewUser(e)} className="form">
                        <div className="container pt-4 px-0">
                            <div className="row ">
                                <h5>
                                    <span className="px-2 " style={{ borderLeft: '3px solid #308D46' }}>USER DETAILS - {updateUser ? "Update" : "New"}</span>
                                </h5>
                            </div>
                        </div>
                        <div className="form-group mt-2">
                            <label htmlFor="inputfirstName" className="col-sm-2 col-form-label">
                                FirstName:
                            </label>
                            <div className="col-sm-10">
                                <input
                                    type="firstName"
                                    className="form-control"
                                    id="inputfirstName"
                                    placeholder="FirstName"
                                    onChange={handleChange}
                                    name="firstName"
                                    value={user.firstName}
                                    required
                                />
                            </div>
                        </div>
                        <div className="form-group my-2">
                            <label htmlFor="inputlastName" className="col-sm-2 col-form-label">
                                LastName:
                            </label>
                            <div className="col-sm-10">
                                <input
                                    type="lastName"
                                    name="lastName"
                                    className="form-control"
                                    id="inputlastName"
                                    placeholder="LastName"
                                    onChange={handleChange}
                                    value={user.lastName}
                                    required
                                />
                            </div>
                        </div>
                        <div className="form-group mt-2">
                            <label htmlFor="staticEmail" className="col-sm-2 col-form-label">
                                Email:
                            </label>
                            <div className="col-sm-10">
                                <input
                                    type="text"
                                    className="form-control"
                                    id="staticEmail"
                                    placeholder="Email@example.com"
                                    onChange={handleChange}
                                    name="email"
                                    value={user.email}
                                    required
                                />
                            </div>
                        </div>
                        <div className="form-group mt-4">
                            <div className="col-sm-10">
                                <input
                                    type="Submit"
                                    className="form-control btn-primary py-3"
                                    id="inputlastName"
                                    readOnly
                                    value={`${loading ? 'Saving.....' : 'Save'}`}
                                    style={{ color: '#fff', fontWeight: 600 }}
                                />
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    );
}

export default ManageUsersForm;