import React from 'react';
import ManageUsersForm from './ManageUsersForm';
import Navbar from './Navbar';
import Users from './Users';
import {
    Switch,
    Route,
    Redirect
} from "react-router-dom";

function App() {
    return (
        <div>
            <Navbar />
            <Switch>
                <Redirect exact from="/" to="/users" />
                <Route exact path="/users">
                    <Users />
                </Route>
                <Route path="/user/:userId">
                    <ManageUsersForm />
                </Route>
                <Route path="*">
                    <p className="text-center my-4"> Resource not found - 404 </p>
                </Route>
            </Switch>

        </div>
    )
}
export default App;