import React, { useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';

export default function Users() {
    const { push } = useHistory();
    const [users, setUsers] = useState([{}]);
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState("");
    const [showAlert, setShowAlert] = useState(false);

    const getUsers = async () => {
        setLoading(true);
        let baseURL = 'http://localhost:8082/users';

        const res = await fetch(baseURL);
        const data = await res.json();
        if (res.ok) {
            setUsers(data.sort((a, b) => a.userId - b.userId));
            setLoading(false);
        } else {
            setMessage(data.msg);
            setLoading(false);
        }

    }

    const removeUser = async (id) => {
        setLoading(true);
        let baseURL = `http://localhost:8082/users/${id}`;

        const res = await fetch(baseURL, {
            method: 'DELETE',
        });
        const data = await res.json();
        if (res.ok) {
            setMessage(data.msg);
            setLoading(false);
        } else {
            setMessage(data.msg);
            setLoading(false);
        }
        showAlertMsg();
    }

    const showAlertMsg = () => {
        setShowAlert(true);
        setTimeout(() => setShowAlert(false), 2000);
    }


    useEffect(() => {
        getUsers();
    }, [message])

    if (loading) {
        return <p className="text-center my-4">Loading.....</p>;
    }

    return (
        <div className="container">
            <div className={`alert alert-success my-3 ${showAlert ? 'd-block' : 'd-none'}`}>
                <strong>Success!: </strong>{message}
            </div>
            <div className="row text-left pt-5">

                <div className="col-8 px-0">
                    <h4 className="px-0"><span className="px-2" style={{ borderLeft: '3px solid #308D46' }}>Manage Users</span></h4>
                </div>
                <div className="col-4 align-self-end px-0" style={{ textAlign: 'right' }}>
                    <button className="btn btn-primary" onClick={() => {
                        push("user/new");
                    }}>
                        Add new user</button>
                </div>
            </div>
            <div className="row py-3">
                <table className="table table-striped text-center">
                    <thead>
                        <tr>
                            <th scope="col">User ID</th>
                            <th scope="col">First</th>
                            <th scope="col">Last</th>
                            <th scope="col">Email</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.map((user, i) => {
                            return (
                                <tr key={i} className="user">
                                    <th scope="row">{user.userId}</th>
                                    <td>{user.firstName}</td>
                                    <td>{user.lastName}</td>
                                    <td>{user.email}</td>
                                    <td>
                                        <button className="btn btn-primary" onClick={() => {
                                            push(`user/${user.userId}`);
                                        }}>
                                            Update
                                        </button>
                                        <button className="btn btn-danger mx-3" onClick={() => {
                                            removeUser(user.userId);
                                        }}>
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            )
                        })}

                    </tbody>
                </table>
            </div>
        </div>
    )
}
